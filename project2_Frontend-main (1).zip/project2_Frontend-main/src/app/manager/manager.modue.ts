export interface Manager {
    	

    managerId: number,
    firstName: String,
    lastName: String,
    address: String,
    contact: String,
    email: String,
    userName: String,
    password: String,
  
}