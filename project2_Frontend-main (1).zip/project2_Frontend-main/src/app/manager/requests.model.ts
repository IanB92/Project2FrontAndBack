export interface Requests {
    pendingId: number,
    employeeId: number,
    reimbursementAmount: number,
    reimbursementReason: String,
    reimbursementDate: String,
    status: String,
    


}