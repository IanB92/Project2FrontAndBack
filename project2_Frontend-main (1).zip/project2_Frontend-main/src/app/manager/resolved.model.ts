export interface Resolved{
    reimbursementId: number,
    employeeId: number,
    reimbursementAmount: number,
    reimbursementReason: String,
    reimbursementDate: String,
    status: String,

    
}