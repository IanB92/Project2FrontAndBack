export interface Denied {
    deniedId: number,
    employeeId: number,
    reimbursementAmount: number,
    reimbursementReason: String,
    reimbursementDate: String,
    status: String,


}