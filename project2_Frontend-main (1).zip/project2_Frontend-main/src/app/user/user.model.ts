export interface User{
        userName: String;
        password: String;
        role: String;
}