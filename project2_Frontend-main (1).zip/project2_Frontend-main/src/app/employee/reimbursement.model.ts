export interface Reimbursement{
    reimbursementId: number;
	employeeId: number;
    reimbursementAmount: number;
	reimbursementReason:String;
	reimbursementDate:String;
	status:String;
}