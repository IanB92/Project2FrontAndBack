export interface Employee{
    employeeId:number;
    employeeFirstName:String;
    employeeLastName:String;
    employeeEmail:String;
    employeeAddress:String;
    employeeContact:String;
    employeeUserName:String;
    employeePassword:String;
}